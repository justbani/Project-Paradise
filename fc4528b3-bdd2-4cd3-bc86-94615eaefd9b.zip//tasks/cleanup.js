let selectedLitter = null;

const litterItems = document.querySelectorAll(".litter");

const bins = document.querySelectorAll(".bin");

const message = document.getElementById("message");

const complete = document.getElementById("complete");

litterItems.forEach(function (item) {
  item.addEventListener("click", function () {
    litterItems.forEach(function (otherItem) {
      otherItem.classList.remove("selected");
    });

    selectedLitter = item;

    item.classList.add("selected");

    message.textContent = "Now choose the correct bin.";
  });
});

bins.forEach(function (bin) {
  bin.addEventListener("click", function () {
    if (!selectedLitter) {
      message.textContent = "Choose a piece of litter first.";

      return;
    }

    const correctBin = selectedLitter.dataset.type;

    const chosenBin = bin.dataset.bin;

    if (correctBin === chosenBin) {
      selectedLitter.remove();

      selectedLitter = null;

      message.textContent = "Correct!";

      checkComplete();
    } else {
      message.textContent = "That's not the right bin. Try again.";
    }
  });
});

function checkComplete() {
  const remaining = document.querySelectorAll(".litter").length;

  if (remaining === 0) {
    localStorage.setItem("parkTaskComplete", "true");

    message.textContent = "";

    complete.style.display = "block";
  }
}

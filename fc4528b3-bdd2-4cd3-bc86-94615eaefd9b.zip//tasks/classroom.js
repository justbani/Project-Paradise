const questions = [
  {
    question: "What is 8 × 7?",
    answers: [54, 56, 64, 48],
    correct: 56,
  },
  {
    question: "Which planet do we live on?",
    answers: ["Mars", "Venus", "Earth", "Jupiter"],
    correct: "Earth",
  },
  {
    question: "What is 25 + 17?",
    answers: [32, 42, 52, 40],
    correct: 42,
  },
];

let currentQuestion = 0;

const questionNumber = document.getElementById("question-number");

const question = document.getElementById("question");

const answers = document.querySelector(".answers");

const feedback = document.getElementById("feedback");

const questionCard = document.getElementById("question-card");

const complete = document.getElementById("complete");

function loadQuestion() {
  const current = questions[currentQuestion];

  questionNumber.textContent = `Question ${currentQuestion + 1} of ${
    questions.length
  }`;

  question.textContent = current.question;

  answers.innerHTML = "";

  current.answers.forEach(function (answer) {
    const button = document.createElement("button");

    button.textContent = answer;

    button.addEventListener("click", function () {
      answerQuestion(answer);
    });

    answers.appendChild(button);
  });

  feedback.textContent = "";
}

function answerQuestion(answer) {
  const current = questions[currentQuestion];

  if (answer === current.correct) {
    feedback.textContent = "Correct!";

    currentQuestion++;

    if (currentQuestion === questions.length) {
      localStorage.setItem("schoolTaskComplete", "true");

      setTimeout(function () {
        questionCard.style.display = "none";

        complete.style.display = "block";
      }, 600);
    } else {
      setTimeout(function () {
        loadQuestion();
      }, 600);
    }
  } else {
    feedback.textContent = "Not quite. Try again.";
  }
}

loadQuestion();

const keys = document.getElementById("keys");
const message = document.getElementById("message");
const complete = document.getElementById("complete");

keys.addEventListener("click", function () {
  localStorage.setItem("homeTaskComplete", "true");

  keys.style.display = "none";

  message.textContent = "You found them!";

  complete.style.display = "block";
});

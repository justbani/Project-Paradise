* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}

body {
    font-family: Arial, sans-serif;
    background: #dff4ff;
    color: #263238;
    min-height: 100vh;
}

button,
a {
    font-family: inherit;
}

button {
    cursor: pointer;
}

/* NAVIGATION */

.corner-nav {
    position: fixed;
    top: 20px;
    right: 20px;
    display: flex;
    gap: 10px;
    z-index: 100;
}

.nav-button {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 10px 15px;
    background: white;
    color: #263238;
    text-decoration: none;
    border: 2px solid #263238;
    border-radius: 10px;
    font-weight: bold;
    box-shadow: 3px 3px 0 #263238;
}

.nav-button:hover {
    transform: translateY(-2px);
}

.nav-icon {
    width: 20px;
    height: 20px;
}

/* HOME PAGE */

.home-page {
    min-height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 90px 30px 40px;
    background:
        linear-gradient(
            180deg,
            #8ed8f5 0%,
            #c9f0ff 55%,
            #b9df9c 55%,
            #b9df9c 100%
        );
}

.welcome-box {
    width: 100%;
    max-width: 720px;
    background: #fffdf4;
    padding: 55px;
    text-align: center;
    border: 4px solid #263238;
    border-radius: 20px;
    box-shadow: 8px 8px 0 #263238;
}

.logo-title {
    font-size: 52px;
    color: #ef6c57;
    margin-bottom: 8px;
}

.welcome-box h2 {
    font-size: 27px;
    color: #287c8c;
    margin-bottom: 30px;
}

.welcome-box p {
    font-size: 18px;
    line-height: 1.6;
    margin-bottom: 18px;
}

.primary-button {
    display: inline-block;
    border: 3px solid #263238;
    background: #f7c948;
    color: #263238;
    padding: 15px 32px;
    font-size: 18px;
    font-weight: bold;
    border-radius: 10px;
    text-decoration: none;
    box-shadow: 4px 4px 0 #263238;
    margin-top: 12px;
}

.primary-button:hover {
    transform: translateY(-2px);
}

.home-links {
    display: flex;
    justify-content: center;
    gap: 20px;
    margin-top: 28px;
}

.secondary-button {
    display: inline-block;
    padding: 12px 22px;
    background: #9bd7a5;
    color: #263238;
    border: 2px solid #263238;
    border-radius: 9px;
    text-decoration: none;
    font-weight: bold;
}

/* GENERAL PAGES */

.page {
    min-height: 100vh;
    max-width: 950px;
    margin: 0 auto;
    padding: 105px 30px 50px;
}

.page-header {
    text-align: center;
    margin-bottom: 35px;
}

.page-header h1 {
    font-size: 40px;
    color: #287c8c;
    margin-bottom: 10px;
}

.page-header p {
    font-size: 18px;
}

/* TODO */

.todo-list {
    display: flex;
    flex-direction: column;
    gap: 18px;
}

.task-section {
    background: #fffdf4;
    padding: 25px;
    border: 3px solid #263238;
    border-radius: 15px;
    box-shadow: 5px 5px 0 #263238;
}

.task-section h2 {
    color: #ef6c57;
    font-size: 25px;
    margin-bottom: 15px;
}

.task {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 15px 0;
    border-top: 2px solid #e4e4dc;
}

.task-checkbox {
    width: 20px;
    height: 20px;
    accent-color: #4c9f70;
}

.task-checkbox:checked + span {
    text-decoration: line-through;
    opacity: 0.5;
}

.locked-task {
    opacity: 0.65;
}

.progress {
    background: #f7c948;
    border: 3px solid #263238;
    box-shadow: 5px 5px 0 #263238;
    border-radius: 15px;
    padding: 20px;
    margin-top: 25px;
    text-align: center;
    font-size: 18px;
}

.progress p {
    margin: 0;
}

.page-navigation {
    display: flex;
    justify-content: center;
    gap: 30px;
    margin-top: 35px;
}

.page-navigation a {
    color: #287c8c;
    font-weight: bold;
    text-decoration: none;
}

.page-navigation a:hover {
    text-decoration: underline;
}

/* MAP */

.map {
    position: relative;
    width: 100%;
    height: 520px;
    background: #a9d98e;
    border: 4px solid #263238;
    border-radius: 20px;
    overflow: hidden;
    box-shadow: 7px 7px 0 #263238;
}

.map-sun {
    position: absolute;
    width: 80px;
    height: 80px;
    background: #f7c948;
    border-radius: 50%;
    top: 30px;
    right: 45px;
}

.map-road {
    position: absolute;
    height: 45px;
    background: #e9d39a;
    border: 3px solid #c2a96c;
    z-index: 1;
}

.road-one {
    width: 360px;
    top: 215px;
    left: 115px;
    transform: rotate(25deg);
}

.road-two {
    width: 330px;
    top: 310px;
    left: 405px;
    transform: rotate(-25deg);
}

.map-location {
    position: absolute;
    z-index: 3;
}

.map-location a {
    display: block;
    min-width: 145px;
    padding: 18px 20px;
    text-align: center;
    background: #fffdf4;
    color: #263238;
    border: 3px solid #263238;
    border-radius: 12px;
    text-decoration: none;
    font-size: 18px;
    font-weight: bold;
    box-shadow: 4px 4px 0 #263238;
}

.map-location a:hover {
    transform: translateY(-3px);
}

.home-location {
    top: 100px;
    left: 80px;
}

.school-location {
    top: 210px;
    left: 370px;
}

.park-location {
    bottom: 65px;
    right: 70px;
}

/* LOCATION PAGES */

.location-card {
    max-width: 700px;
    margin: 0 auto;
    background: #fffdf4;
    padding: 40px;
    border: 3px solid #263238;
    border-radius: 16px;
    box-shadow: 6px 6px 0 #263238;
    text-align: center;
}

.location-card h2 {
    font-size: 28px;
    color: #ef6c57;
    margin-bottom: 18px;
}

.location-card p {
    font-size: 18px;
    line-height: 1.6;
    margin-bottom: 20px;
}

.task-start-button {
    display: inline-block;
    background: #f7c948;
    color: #263238;
    padding: 15px 28px;
    border: 3px solid #263238;
    border-radius: 10px;
    font-weight: bold;
    font-size: 17px;
    text-decoration: none;
    box-shadow: 4px 4px 0 #263238;
}

.task-start-button:hover {
    transform: translateY(-2px);
}

.completed-message {
    margin-top: 20px;
    font-weight: bold;
    color: #4c9f70;
}

/* EVENT */

.event-card {
    max-width: 700px;
    margin: 0 auto;
    background: #fffdf4;
    padding: 40px;
    border: 4px solid #ef6c57;
    border-radius: 18px;
    box-shadow: 7px 7px 0 #263238;
    text-align: center;
}

.event-card h2 {
    color: #ef6c57;
    font-size: 28px;
    margin-bottom: 20px;
}

.event-card p {
    font-size: 18px;
    line-height: 1.6;
    margin-bottom: 18px;
}

.event-card h3 {
    margin: 28px 0 20px;
    font-size: 21px;
}

.event-choices {
    display: flex;
    justify-content: center;
    gap: 18px;
    flex-wrap: wrap;
}

.event-choice {
    border: 3px solid #263238;
    padding: 14px 25px;
    border-radius: 10px;
    background: #9bd7a5;
    font-size: 16px;
    font-weight: bold;
    box-shadow: 4px 4px 0 #263238;
}

.event-choice:hover {
    transform: translateY(-2px);
}

.event-choice:last-child {
    background: #f7c948;
}

#event-result {
    margin-top: 25px;
    font-weight: bold;
}

/* ENDING */

.ending-card {
    max-width: 700px;
    margin: 0 auto;
    background: #fffdf4;
    padding: 45px;
    border: 4px solid #263238;
    border-radius: 18px;
    box-shadow: 8px 8px 0 #263238;
    text-align: center;
}

.ending-card h2 {
    font-size: 34px;
    color: #4c9f70;
    margin-bottom: 20px;
}

.ending-card p {
    font-size: 18px;
    line-height: 1.6;
    margin-bottom: 25px;
}

.restart-button {
    border: 3px solid #263238;
    background: #f7c948;
    padding: 14px 28px;
    border-radius: 10px;
    font-size: 17px;
    font-weight: bold;
    box-shadow: 4px 4px 0 #263238;
}

.restart-button:hover {
    transform: translateY(-2px);
}

/* MOBILE */

@media (max-width: 700px) {
    .corner-nav {
        right: 10px;
        top: 10px;
    }

    .nav-button {
        padding: 8px 10px;
        font-size: 13px;
    }

    .welcome-box {
        padding: 35px 25px;
    }

    .logo-title {
        font-size: 40px;
    }

    .home-links {
        flex-direction: column;
    }

    .map {
        height: 550px;
    }

    .home-location {
        left: 25px;
    }

    .school-location {
        left: 50%;
        transform: translateX(-50%);
    }

    .park-location {
        right: 25px;
    }

    .road-one,
    .road-two {
        display: none;
    }

    .event-choices {
        flex-direction: column;
    }
}

```javascript
// Make Your Own Paradise

const addTaskButton = document.getElementById("add-task-button");
const customTaskInput = document.getElementById("custom-task");
const customTaskList = document.getElementById("custom-task-list");

if (addTaskButton) {
    addTaskButton.addEventListener("click", addCustomTask);
}

if (customTaskInput) {
    customTaskInput.addEventListener("keydown", function(event) {
        if (event.key === "Enter") {
            addCustomTask();
        }
    });
}

function addCustomTask() {
    const taskText = customTaskInput.value.trim();

    if (taskText === "") {
        return;
    }

    const task = document.createElement("label");
    task.className = "task custom-task";

    task.innerHTML = `
        <input type="checkbox" class="task-checkbox">
        <span>${taskText}</span>
    `;

    customTaskList.appendChild(task);

    customTaskInput.value = "";
    customTaskInput.focus();
}
```
